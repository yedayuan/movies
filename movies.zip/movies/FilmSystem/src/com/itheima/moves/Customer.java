package com.itheima.moves;


import java.io.Serializable;

/**
 * 客户类
 *
 */
public class Customer extends User implements Serializable {
}
